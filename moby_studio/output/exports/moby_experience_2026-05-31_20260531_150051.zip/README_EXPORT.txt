Moby Studio export

Abre esta experiencia sirviendo la carpeta descomprimida con un servidor HTTP local.
Entrada: index.html
Layout: output/layout.json
